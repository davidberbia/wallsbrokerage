@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py) || (set PY=python)
%PY% --version >nul 2>nul || (
  echo Python n'est pas installe. Installez-le depuis https://www.python.org/downloads/ en cochant "Add python.exe to PATH", puis relancez.
  pause & exit /b
)
%PY% -m pip install --quiet --disable-pip-version-check requests openpyxl xlrd pypdf python-docx
%PY% walls_nas.py

pause
