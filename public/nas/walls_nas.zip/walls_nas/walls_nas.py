#!/usr/bin/env python3
"""Walls Brokerage — aspiration du NAS vers le CRM.

Mode actifs      : Investissement / Année / Ville / [Adresse] / fichiers
Mode comparables : dossier de fichiers Excel (une ligne = un comparable)
Reprise sans doublon (empreinte SHA-256), 10 envois en parallèle.
"""
import hashlib, json, os, re, sys, math, datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests

API = os.environ.get("WALLS_NAS_API", "https://wallsbrokerage.com/api/public/nas-ingest")
CONF = Path(os.environ.get("APPDATA", str(Path.home()))) / "walls_nas.json"
SKIP_EXT = {".db", ".tmp", ".lnk", ".ini", ".ds_store"}
MAX_MB = 200
WORKERS = 10

def load_conf():
    return json.loads(CONF.read_text("utf-8")) if CONF.exists() else {}

def save_conf(c):
    CONF.write_text(json.dumps(c, ensure_ascii=False, indent=1), "utf-8")

def call(key, action, **body):
    for attempt in range(4):
        try:
            r = requests.post(API, json={"action": action, **body}, headers={"x-nas-key": key}, timeout=120)
            if r.status_code == 401: sys.exit("Clé refusée : générez une nouvelle clé dans Paramètres > Serveur NAS.")
            r.raise_for_status()
            return r.json()
        except requests.RequestException as e:
            if attempt == 3: raise
            import time; time.sleep(60)  # coupure : reprise après 1 minute

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()

def files_under(root):
    for p in Path(root).rglob("*"):
        if p.is_file() and not p.name.startswith(("~$", ".")) and p.suffix.lower() not in SKIP_EXT and p.stat().st_size <= MAX_MB << 20:
            yield p

# ---------- Comparables depuis baux / états locatifs (règles, sans IA) ----------
NUM = r"(\d{1,3}(?:[ \u00a0\u202f.]\d{3})*(?:,\d+)?|\d+(?:,\d+)?)"
def tonum(s):
    try: return float(re.sub(r"[ \u00a0\u202f.]", "", s).replace(",", "."))
    except ValueError: return None

def doc_text(p):
    ext = p.suffix.lower()
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            return "\n".join((pg.extract_text() or "") for pg in PdfReader(str(p)).pages[:20])
        if ext == ".docx":
            import docx
            return "\n".join(par.text for par in docx.Document(str(p)).paragraphs)
    except Exception:
        return ""
    return ""

def lease_comparable(p, city, label):
    if not re.search(r"bail|etat.?locatif|état.?locatif", p.name, re.I): return None
    t = doc_text(p)
    if not t: return None
    loyer = re.search(r"loyer[^\n€]{0,80}?" + NUM + r"\s*(?:€|euros)", t, re.I)
    surf = re.search(NUM + r"\s*m(?:²|2)\b", t)
    if not loyer or not surf: return None
    rent, surface = tonum(loyer.group(1)), tonum(surf.group(1))
    if not rent or not surface or rent < 1000 or surface < 5: return None
    return {"kind": "location", "city": city, "address": label if label != city else None,
            "surface": surface, "rent": rent, "source": f"NAS · {p.name}"}

# ---------- Mode actifs ----------
def run_actifs(key, root):
    root = Path(root)
    jobs = []
    for year_dir in sorted(d for d in root.iterdir() if d.is_dir()):
        for city_dir in sorted(d for d in year_dir.iterdir() if d.is_dir()):
            subs = [d for d in city_dir.iterdir() if d.is_dir()]
            loose = [f for f in city_dir.iterdir() if f.is_file()]
            if loose or not subs:
                jobs.append((year_dir.name, city_dir.name, city_dir.name, city_dir, loose and [f for f in loose] or list(files_under(city_dir))))
            for s in subs:
                jobs.append((year_dir.name, city_dir.name, s.name, s, list(files_under(s))))
    print(f"{len(jobs)} dossier(s) d'actifs trouvés. Calcul des empreintes…")
    all_files = [(j, f) for j in jobs for f in j[4]]
    hashes = {}
    for i, (_, f) in enumerate(all_files, 1):
        hashes[f] = sha(f)
        if i % 200 == 0: print(f"  {i}/{len(all_files)}")
    known = set()
    hl = list(set(hashes.values()))
    for i in range(0, len(hl), 2000):
        known |= set(call(key, "check", hashes=hl[i:i + 2000])["known"])
    todo = [(j, f) for j, f in all_files if hashes[f] not in known]
    print(f"{len(todo)} fichier(s) à envoyer ({len(all_files) - len(todo)} déjà dans le CRM).")

    def send(job, f):
        year, city, label, folder, _ = job
        h = hashes[f]
        rel = str(f.relative_to(root))
        u = call(key, "upload-url", folder_path=str(folder.relative_to(root)), year=year, city=city, label=label, name=f.name, sha256=h)
        with open(f, "rb") as fh:
            r = requests.put(u["signedUrl"], data=fh, headers={"Content-Type": "application/octet-stream", "x-upsert": "true"}, timeout=600)
        r.raise_for_status()
        call(key, "commit", sha256=h, rel_path=rel, path=u["path"], name=f.name, folder_id=u["folder_id"], asset_id=u["asset_id"], category=u["category"], size=f.stat().st_size)
        comp = lease_comparable(f, city, label)
        if comp: call(key, "comparables", rows=[comp])
        return rel

    done = errors = 0
    with ThreadPoolExecutor(WORKERS) as ex:
        futs = [ex.submit(send, j, f) for j, f in todo]
        for fu in as_completed(futs):
            try: fu.result(); done += 1
            except Exception as e: errors += 1; print("  erreur :", e)
            if (done + errors) % 25 == 0: print(f"  {done + errors}/{len(todo)} envoyés")
    print(f"Terminé : {done} envoyé(s), {errors} erreur(s). Relancez pour reprendre les erreurs.")

# ---------- Mode comparables ----------
SYN = {
    "address": ["adresse", "rue", "voie"], "number": ["n°", "no", "numero", "num"],
    "city": ["ville", "commune", "arrdt ville", "localite"], "postal_code": ["cp", "code postal"],
    "enseigne": ["enseigne", "enseignes", "preneur", "locataire"],
    "surface": ["surface totale", "surface total", "surfaces m2", "surface", "total", "sdp"],
    "weighted_surface": ["surface ponderee", "s pond", "pond"],
    "rent": ["loyer / euro", "loyer annuel", "loyer € ht-hc/an", "loyer/an", "loyer"],
    "rent_m2": ["val. loc. / euro", "valeur locative", "loyer / m2", "loyer m2"],
    "price": ["vente / euro", "prix de vente", "prix", "vte €", "vte"],
    "price_m2": ["val. ven. / euro", "prix / m2", "valeur m2"],
    "yield_pct": ["rendement", "rentabilite", "renta"],
    "deal_date": ["date", "date de signature"], "asset_class": ["typologie", "type", "classe", "activite"],
    "notes": ["commentaire", "notes", "observations"],
}
import unicodedata
def nk(s): return re.sub(r"\s+", " ", unicodedata.normalize("NFD", str(s)).encode("ascii", "ignore").decode().lower()).strip()

def map_headers(headers):
    m = {}
    hs = [nk(h) for h in headers]
    for field, syns in SYN.items():
        for s in syns:
            s = nk(s)
            idx = next((i for i, h in enumerate(hs) if h == s), None)
            if idx is None: idx = next((i for i, h in enumerate(hs) if h.startswith(s)), None)
            if idx is not None and idx not in m.values(): m[field] = idx; break
    return m

def cell_num(v):
    if v is None or v == "": return None
    if isinstance(v, (int, float)): return None if isinstance(v, float) and math.isnan(v) else float(v)
    s = re.sub(r"[^0-9,.\-]", "", str(v).replace(" ", "")).replace(",", ".")
    try: return float(s) if s not in ("", "-", ".") else None
    except ValueError: return None

def cell_date(v):
    if isinstance(v, (datetime.date, datetime.datetime)): return v.strftime("%Y-%m-%d")
    m = re.match(r"(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})", str(v or ""))
    if m:
        d, mo, y = map(int, m.groups()); y = y + 2000 if y < 100 else y
        try: return datetime.date(y, mo, d).isoformat()
        except ValueError: return None
    return None

def sheets(p):
    ext = p.suffix.lower()
    if ext == ".xls":
        import xlrd
        wb = xlrd.open_workbook(str(p))
        for sh in wb.sheets():
            yield sh.name, [sh.row_values(i) for i in range(sh.nrows)]
    elif ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
        for ws in wb.worksheets:
            yield ws.title, [list(r) for r in ws.iter_rows(values_only=True)]
    elif ext == ".csv":
        import csv
        with open(p, encoding="utf-8-sig", errors="ignore") as f:
            yield "csv", list(csv.reader(f, delimiter=";" if ";" in f.readline() else ",")); 

def rows_of(p):
    out = []
    for name, data in sheets(p):
        hi = next((i for i, r in enumerate(data[:15]) if sum(1 for c in r if c not in (None, "")) >= 3 and len(map_headers(r)) >= 3), None)
        if hi is None: continue
        m = map_headers(data[hi])
        if "address" not in m and "city" not in m: continue
        g = lambda r, k: r[m[k]] if k in m and m[k] < len(r) else None
        for r in data[hi + 1:]:
            adr = " ".join(str(x).replace(".0", "").strip() for x in (g(r, "number"), g(r, "address")) if x not in (None, ""))
            city = str(g(r, "city") or "").strip()
            row = {"address": adr or None, "city": city or None, "postal_code": str(g(r, "postal_code") or "").replace(".0", "") or None,
                   "enseigne": str(g(r, "enseigne") or "").strip() or None, "asset_class": str(g(r, "asset_class") or "") or None,
                   "notes": str(g(r, "notes") or "")[:2000] or None, "deal_date": cell_date(g(r, "deal_date")),
                   "source": f"NAS · {p.name}/{name}"}
            for k in ("surface", "weighted_surface", "rent", "rent_m2", "price", "price_m2", "yield_pct"):
                row[k] = cell_num(g(r, k))
            if not (row["address"] or row["city"]) or not any(row[k] for k in ("surface", "rent", "price", "rent_m2", "price_m2")): continue
            row["kind"] = "vente" if row["price"] and not row["rent"] else "location"
            out.append(row)
    return out

def run_comparables(key, root):
    files = [p for p in files_under(root) if p.suffix.lower() in (".xls", ".xlsx", ".xlsm", ".csv")]
    print(f"{len(files)} fichier(s) Excel/CSV trouvés.")
    hs = {p: sha(p) for p in files}
    known = set(call(key, "check", hashes=list(hs.values()))["known"]) if hs else set()
    total = 0
    for p in files:
        if hs[p] in known: print(f"  déjà importé : {p.name}"); continue
        try: rows = rows_of(p)
        except Exception as e: print(f"  illisible : {p.name} ({e})"); continue
        ins = skip = 0
        for i in range(0, len(rows), 1000):
            last = i + 1000 >= len(rows)
            r = call(key, "comparables", rows=rows[i:i + 1000], **({"sha256": hs[p], "rel_path": str(p)} if last else {}))
            ins += r["inserted"]; skip += r["skipped"]
        if not rows: call(key, "comparables", rows=[], sha256=hs[p], rel_path=str(p))
        total += ins
        print(f"  {p.name} : {ins} ajouté(s), {skip} doublon(s)")
    print(f"Terminé : {total} comparable(s) ajouté(s).")

def main():
    c = load_conf()
    key = c.get("key") or input("Collez la clé du CRM (Paramètres > Serveur NAS) : ").strip()
    c["key"] = key; save_conf(c)
    call(key, "ping")
    print("1 = Actifs (dossier Investissement)\n2 = Comparables (fichiers Excel)")
    mode = (sys.argv[1] if len(sys.argv) > 1 else input("Choix : ")).strip()
    default = c.get("dir_" + mode, "")
    path = input(f"Dossier{f' [{default}]' if default else ''} (ex. Z:\\Investissement) : ").strip().strip('"') or default
    if not Path(path).is_dir(): sys.exit("Dossier introuvable.")
    c["dir_" + mode] = path; save_conf(c)
    (run_actifs if mode == "1" else run_comparables)(key, path)

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("\nArrêté. Relancez pour reprendre.")
    input("Appuyez sur Entrée pour fermer.")
